package messenger;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import java.text.*;
public class databaseConnection {
    Connection con=null;
    Statement stmt=null;
    String url="jdbc:mysql://localhost/messenger";
    String user = "root";
    String passwd = "1111";
    databaseConnection(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url, user, passwd);
            stmt = con.createStatement();
            System.out.println("MySQL 서버 연동 성공");
            System.out.println(con);
        }
        catch(Exception e){
            System.out.println("MySQL 서버 연동 실패 > ");
            e.printStackTrace();

        }

    }
    boolean newIDCheck(String userID){
        boolean check=false;
        try{
            String str="select id from user";
            ResultSet result=stmt.executeQuery(str);
            int count=0;
            while(result.next()){
                if(userID.equals(result.getString("id"))){
                    check=true;
                    System.out.println("아이디 중복");
                }
                else{
                    check=false;
                }
            }
        }
        catch(Exception e){
            check=false;
            e.printStackTrace();
        }
        return check;
    }
    void inputUserData(String id,String pw,String name,String nick,String email,String birth){
        PreparedStatement stmt=null;
        try{
            String str="insert into user(id ,pw,nickname,birth,email,name) values(?,?,?,?,?,?)";
            stmt=con.prepareStatement(str);

            stmt.setString(1,id);
            stmt.setString(2,pw);
            stmt.setString(3,nick);
            stmt.setString(4,birth);
            stmt.setString(5,email);
            stmt.setString(6,name);
            stmt.execute();
            stmt.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}
