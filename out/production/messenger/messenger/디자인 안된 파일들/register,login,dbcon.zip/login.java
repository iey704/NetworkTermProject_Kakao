package messenger;

import javax.swing.*;
import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JPasswordField;


public class login extends JFrame {
    private JPanel contentPane;
    private JPasswordField passwordField;
    public login(){
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 197, 187);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("ID");
        lblNewLabel.setBounds(12, 10, 52, 15);
        contentPane.add(lblNewLabel);

        JTextArea textArea = new JTextArea();
        textArea.setBounds(12, 25, 159, 22);
        contentPane.add(textArea);

        JButton btnNewButton = new JButton("Login");
        btnNewButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
            String id=textArea.getText();
            String pw="";
            char tempPW[]=passwordField.getPassword();
            for(char c:tempPW){
                Character.toString(c);
                pw+=""+c+"";
            }

            }
        });
        btnNewButton.setBounds(12, 115, 70, 23);
        contentPane.add(btnNewButton);

        JLabel lblNewLabel_1 = new JLabel("PW");
        lblNewLabel_1.setBounds(12, 57, 52, 15);
        contentPane.add(lblNewLabel_1);

        JButton btnNewButton_1 = new JButton("Register");
        btnNewButton_1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                dispose();
                new register();
            }
        });
        btnNewButton_1.setBounds(85, 115, 86, 23);
        contentPane.add(btnNewButton_1);

        passwordField = new JPasswordField();
        passwordField.setBounds(12, 82, 159, 21);
        contentPane.add(passwordField);
        setVisible(true);
    }

}