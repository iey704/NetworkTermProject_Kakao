package messenger;
import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Date;
import java.util.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class register extends JFrame{
    private JPanel contentPane;
    private JTextField textField;
    private JPasswordField passwordField;
    private JTextField textField_2;
    private JTextField textField_3;
    private JTextField textField_4;
    private JTextField textField_5;
    private databaseConnection db;

    public register(){
       // db=new databaseConnection();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 375, 161);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("ID");
        lblNewLabel.setBounds(12, 10, 52, 15);
        contentPane.add(lblNewLabel);

        textField = new JTextField();
        textField.setBounds(12, 24, 106, 21);
        contentPane.add(textField);
        textField.setColumns(10);

        JLabel lblNewLabel_1 = new JLabel("PW");
        lblNewLabel_1.setBounds(12, 55, 52, 15);
        contentPane.add(lblNewLabel_1);

        passwordField = new JPasswordField();
        passwordField.setBounds(12, 69, 106, 21);
        contentPane.add(passwordField);

        JLabel lblNewLabel_2 = new JLabel("Name");
        lblNewLabel_2.setBounds(130, 10, 52, 15);
        contentPane.add(lblNewLabel_2);

        textField_2 = new JTextField();
        textField_2.setText("");
        textField_2.setBounds(130, 24, 106, 21);
        contentPane.add(textField_2);
        textField_2.setColumns(10);

        JLabel lblNewLabel_3 = new JLabel("Nickname");
        lblNewLabel_3.setBounds(130, 55, 72, 15);
        contentPane.add(lblNewLabel_3);

        textField_3 = new JTextField();
        textField_3.setBounds(130, 69, 106, 21);
        contentPane.add(textField_3);
        textField_3.setColumns(10);

        JLabel lblNewLabel_4 = new JLabel("E-mail");
        lblNewLabel_4.setBounds(248, 10, 52, 15);
        contentPane.add(lblNewLabel_4);

        textField_4 = new JTextField();
        textField_4.setBounds(248, 24, 106, 21);
        contentPane.add(textField_4);
        textField_4.setColumns(10);

        JLabel lblNewLabel_5 = new JLabel("Birth(xxxx-xx-xx)");
        lblNewLabel_5.setBounds(248, 55, 106, 15);
        contentPane.add(lblNewLabel_5);

        textField_5 = new JTextField();
        textField_5.setBounds(248, 69, 106, 21);
        contentPane.add(textField_5);
        textField_5.setColumns(10);

        JButton btnNewButton = new JButton("Register");
        btnNewButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String id=textField.getText();
                String pw="";
                char tempPW[]=passwordField.getPassword();
                for(char c:tempPW){
                    Character.toString(c);
                    pw+=""+c+"";
                }
                String name=textField_2.getText();
                String nic=textField_3.getText();
                String email=textField_4.getText();
                String birth=textField_5.getText();
                db= new databaseConnection();
            if(passwordField.getPassword().equals("")||textField.getText().equals("")||textField_2.getText().equals("")||(textField_3.getText().equals(""))||textField_4.getText().equals("")||textField_5.getText().equals("")){
                    JOptionPane.showMessageDialog(null,
                            "모두 입력해주세요","회원가입 실패", JOptionPane.ERROR_MESSAGE);
                }
                else if(passwordField!=null&&textField!=null&&textField_2!=null&&textField_3!=null&&textField_4!=null&&textField_5!=null){
                    if(db.newIDCheck(textField.getText())){
                        JOptionPane.showMessageDialog(null, "같은 아이디가 존재합니다. " + "다른 아이디를 선택하여 주십시오.");
                    }
                    else{
                        System.out.println(id+pw+nic+email+birth);
                        db.inputUserData(id,pw,name,nic,email,birth);
                        System.out.println("회원가입 성공");
                        new login();
                        dispose();
                    }
            }
            }
        });
        btnNewButton.setBounds(12, 100, 342, 23);
        contentPane.add(btnNewButton);
        setVisible(true);
    }

}
